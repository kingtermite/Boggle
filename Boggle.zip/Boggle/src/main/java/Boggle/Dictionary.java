import java.util.*;

// Assumption: Not using a mocking library to swap out objects at runtime
// Just mocking the Dictionary class
public class Dictionary
{

   // Mock method for actual Dictionary class' isEnglishWord() method. This method
   // just uses a few sample words to return. Doesn't really matter if they are
   // real dictionary words here or not, as long as my test only pulls these strings
   // out from this method to keep in set.
   public static boolean isEnglishWord(String testWord)
   {
      List<String> words = List.of("cab", "ab", "ba", "a", /* abc */
      "damned", "dam", "man", "mad", "den", "dad", "mane", "name", "named", "dame", "dead", /* damned */
      "working", "work", "king", "ring", "row", "know", "wing", "rowing", "win", "wig", "wok" /* working */
      );
      return words.contains(testWord);
   }

}