import java.util.*;

public class Boggle
{

   // Test Runner
   public static void main(String[] args)
   {
      List<String> testWords = List.of("abc", "damned", "working");
      Set<String> set = null;

      for(String s: testWords)
      {
         s = s.toLowerCase();
         set = getEnglishWordsFromString(s);
         System.out.println("All possible (English) words from " + s + ":");
         System.out.println(set);
         set.clear();
      }

   }


   // Clean up set (remove strings that are not english words)
   private static Set<String> getEnglishWordsFromString(String word)
   {
      // main data structure to store words is a set to keep duplicates out
      // Use TreeSet over HashSet because it orders it more nicely for only slight performance tradeoff
      Set<String> set = new TreeSet<String>();
      addSubwords(word, set);

      // Add subwords only adds all subwords "in order", but not permutations
      ArrayList<String> allPerms = new ArrayList<String>();

      try
      {
         for(String subword : set)
         {
            allPerms.addAll(permutation(subword));
         }
         set.addAll(allPerms); // adds all permutations of each subword to set

         set.removeIf(s -> !Dictionary.isEnglishWord(s)); // Clean out non-words
      }
      catch(Exception e)
      {
         System.out.println("Exception caught in getEnglishWordsFromString(). No bueno!");
         System.out.println(e.getMessage());
         e.printStackTrace();
      }
      return set;
   }

   // Find/add subwords to the set
   private static void addSubwords(String word, Set<String> wordSet)
   {
       for(int i = 0; i < word.length(); i++)
       {
           // Use HashSet for temp for fast adding
           Set<String> temp = new HashSet<String>();
           char c = word.charAt(i);

         try
         {
           // For each substring already found, concat next char
           for(String str: wordSet)
           {
                  temp.add(str + c);
           }

           wordSet.add(Character.toString(c)); // Add that single char as word
           wordSet.addAll(temp); // Add all found in temp
         }
         catch(Exception e)
         {
            System.out.println("Exception caught in addSubword(). No bueno!");
            System.out.println(e.getMessage());
            e.printStackTrace();
         }
       }
   }

   // Return ArrayList of strings with all permutations of s
   private static ArrayList<String> permutation(String s)
   {
       ArrayList<String> result = new ArrayList<String>();

       // If input string's length is 1, return {s} [Recursion Base Case]
       if (s.length() == 1)
       {
         try
         {
            result.add(s);
         }
         catch(Exception e)
         {
            System.out.println("Exception caught in permutation(). No bueno!");
            System.out.println(e.getMessage());
            e.printStackTrace();
         }
       }
       else if (s.length() > 1)
       {
           int lastIndex = s.length() - 1;

           // Find out the last character as a string
           String last = s.substring(lastIndex);

           // Rest of the string
           String restOfString = s.substring(0, lastIndex);

           // Perform permutation on the rest string and
           // merge with the last character
           result = merge(permutation(restOfString), last);
       }
       return result;
   }

   // Merge current list with char in c inserted into each position in each string.
   private static ArrayList<String> merge(ArrayList<String> list, String c)
   {
       ArrayList<String> result = new ArrayList<String>();

       for (String s : list)
       {
         try
         {
           // For each string in list, insert the last character to all possible postions
           // and add them to the new list
           for (int i = 0; i <= s.length(); i++)
           {
               String newguy = new StringBuffer(s).insert(i, c).toString();
               result.add(newguy);
           }
        }
        catch(Exception e)
        {
           System.out.println("Exception caught in merge(). No bueno!");
           System.out.println(e.getMessage());
           e.printStackTrace();
        }
       }
       return result;
   }


}